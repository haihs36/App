package com.example.licham;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText edtDL;
    Button btnSearch;
    TextView txtResult, txtAlert;
    ImageView imgIcon;
    TableLayout tbLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Lấy năm hiện tại
        edtDL = findViewById(R.id.edtDL);
        btnSearch = findViewById(R.id.btnSearch);
        txtResult = findViewById(R.id.txtResult);
        txtAlert = findViewById(R.id.txtAlert);
        imgIcon = findViewById(R.id.imgIcon);

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                try {
                    hideKeyboard();
                    tbLayout.removeAllViews();
                    txtAlert.setText("");
                    int year = Integer.parseInt(edtDL.getText().toString());
                    final int MIN_VALID_YEAR = 1000;

                    if (year < MIN_VALID_YEAR) {
                        txtAlert.setText("Năm không hợp lệ");
                        return;
                    }

                    calculateCanChi(year);
                } catch (Exception e) {
                    txtAlert.setText("Năm không hợp lệ");
                }
            }
        });
        // Load dữ liệu mặc định khi ứng dụng khởi động
        edtDL.setText(currentYear + "");
        calculateCanChi(currentYear);
    }

    private void tableLayout() {
        tbLayout = findViewById(R.id.tbLayout); // Tham chiếu đến TableLayout trong layout XML
        // Tạo tiêu đề cột
        TableRow headerRow = new TableRow(this);
        String[] headers = {"Âm - Dương", "Con giáp", "Hướng", "Mùa", "Tháng âm lịch"};
        for (String header : headers) {
            TextView textView = new TextView(this);
            textView.setText(header);
            textView.setPadding(20, 10, 20, 10);
            // Áp dụng đường viền cho header
            textView.setBackgroundResource(R.drawable.table_border);
            headerRow.addView(textView);
        }
        tbLayout.addView(headerRow); // Thêm tiêu đề cột vào bảng

        // Tạo dữ liệu cho bảng
        String[][] data = {
                {"Âm", "Con giáp âm", "Hướng âm", "Mùa âm", "Tháng âm"},
                {"Dương", "Con giáp dương", "Hướng dương", "Mùa dương", "Tháng dương"}
        };

        for (String[] rowData : data) {
            TableRow row = new TableRow(this);
            for (String cellData : rowData) {
                TextView cell = new TextView(this);
                cell.setText(cellData);
                cell.setPadding(20, 10, 20, 10);
                cell.setBackgroundResource(R.drawable.table_border);
                row.addView(cell);
            }
            tbLayout.addView(row); // Thêm dữ liệu hàng vào bảng
        }
    }

    private void hideKeyboard() {
        // Ẩn bàn phím khi button được bấm
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(txtResult.getWindowToken(), 0);
    }

    // Hàm tính can và chi cho một năm cụ thể
    private void calculateCanChi(int nam_duong_lich) {

        String can = "", chi = "", ngu_hanh = "", am_duong = "", con_giap = "", mua = "", thang_am = "";
        //tinh can Danh sách 10 can
        switch (nam_duong_lich % 10) {
            case 0:
                can = "Canh";
                ngu_hanh = "Kim";
                break;
            case 1:
                can = "Tân";
                ngu_hanh = "Kim";
                break;
            case 2:
                can = "Nhâm";
                ngu_hanh = "Thủy";
                break;
            case 3:
                can = "Quý";
                ngu_hanh = "Thủy";
                break;
            case 4:
                can = "Giáp";
                ngu_hanh = "Mộc";
                break;
            case 5:
                can = "Ất";
                ngu_hanh = "Mộc";
                break;
            case 6:
                can = "Bính";
                ngu_hanh = "Hỏa";
                break;
            case 7:
                can = "Đinh";
                ngu_hanh = "Hỏa";
                break;
            case 8:
                can = "Mậu";
                ngu_hanh = "Thổ";
                break;
            case 9:
                can = "Kỷ";
                ngu_hanh = "Thổ";
                break;
        }
        //tinh chi Danh sách 12 Chi
        int type_chi = nam_duong_lich % 12;

        switch (type_chi) {
            case 0:
                chi = "Thân";
                am_duong = "Dương";
                ngu_hanh = "khỉ";
                mua = "Thu";
                thang_am = "7";
                break;
            case 1:
                chi = "Dậu";
                am_duong = "Âm";
                ngu_hanh = "Gà";
                mua = "Thu";
                thang_am = "8";
                break;
            case 2:
                chi = "Tuất";
                am_duong = "Dương";
                ngu_hanh = "Chó";
                mua = "Thu";
                thang_am = "9";
                break;

            case 3:
                chi = "Hợi";
                am_duong = "Âm";
                ngu_hanh = "Lợn nhà | Lợn rừng";
                mua = "Đông";
                thang_am = "10";
                break;

            case 4:
                chi = "Tý";
                am_duong = "Dương";
                con_giap = "Chuột";
                mua = "Đông";
                thang_am = "11 (đông chí)";
                break;
            case 5:
                chi = "Sửu";
                am_duong = "Âm";
                con_giap = "Trâu | Bò";
                mua = "Đông";
                thang_am = "12";
                break;
            case 6:
                chi = "Dần";
                am_duong = "Dương";
                con_giap = "Hổ";
                mua = "Xuân";
                thang_am = "1";
                break;
            case 7:
                chi = "Mão";
                am_duong = "Âm";
                con_giap = "Mèo | Thỏ";
                mua = "Xuân";
                thang_am = "2 (xuân phân)";

                break;
            case 8:
                chi = "Thìn";
                am_duong = "Dương";
                ngu_hanh = "Rồng";
                mua = "Xuân";
                thang_am = "3";
                break;
            case 9:
                chi = "Tỵ";
                am_duong = "Âm";
                ngu_hanh = "Rắn";
                mua = "hè";
                thang_am = "4";
                break;
            case 10:
                chi = "Ngọ";
                am_duong = "Dương";
                ngu_hanh = "Ngựa";
                mua = "Hè";
                thang_am = "5 (hạ chí)";
                break;
            case 11:
                chi = "Mùi";
                am_duong = "Âm";
                ngu_hanh = "Dê";
                mua = "Hè";
                thang_am = "6";
                break;

        }

        // Lấy ID của tài nguyên hình ảnh từ tên tập tin
        int imageResource = getResources().getIdentifier("image_" + type_chi, "drawable", getPackageName());

        if (imageResource != 0) {
            imgIcon.setImageResource(imageResource);
        }

        txtResult.setText(can + " " + chi);

        tableLayout();

    }
}